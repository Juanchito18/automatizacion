package com.bam.certification.movilbam.stepdefinitions;

import com.bam.certification.movilbam.questions.Resultado;
import com.bam.certification.movilbam.tasks.Calcular;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.screenplay.GivenWhenThen;
import net.serenitybdd.screenplay.actors.OnlineCast;
import org.hamcrest.Matchers;

import java.util.List;

import static net.serenitybdd.screenplay.actors.OnStage.*;
import static net.serenitybdd.screenplay.actors.OnStage.setTheStage;

public class BasicMathOperationsStepdefinitions {
    @Before
    public void setUp() {
        setTheStage(new OnlineCast());
    }

    @Given("^that the user is in the Calculator app$")
    public void thatTheUserIsInTheCalculatorApp()  {
    theActorCalled("JuanDa").wasAbleTo();
    }

    @When("^he operates two numbers$")
    public void heOperatesTwoNumbers(List<String> digitos) {
       theActorInTheSpotlight().has(Calcular.laOperacion(digitos.get(3))
                .operandoElNumeroUno(digitos.get(4)).conElSegundoNumero(digitos.get(5)));
    }

    @Then("^Can view the result (.*)$")
    public void canViewTheResult(String resultado_esperado) {
        theActorInTheSpotlight().should(GivenWhenThen.seeThat(Resultado.obtenido(), Matchers.is(resultado_esperado)));
    }

}
