package com.bam.certification.movilbam.runners;

import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.runner.RunWith;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(features="src/test/resources/features/mathematical_operations.feature"
        ,glue="com.bam.certification.movilbam.stepdefinitions"
        ,snippets= SnippetType.CAMELCASE)

public class BasicMathOperations {
}
