package com.bam.certification.movilbam.questions;
import com.bam.certification.movilbam.userinterfaces.ResultadoPage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;

public class Resultado implements Question<String>{

	public static Resultado obtenido() {
		return new Resultado();
	}

	@Override
	public String answeredBy(Actor actor) {
	
		return Text.of(ResultadoPage.VALOR_ESPERADO).viewedBy(actor).asString();
	}

}
