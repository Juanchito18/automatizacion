package com.bam.certification.movilbam.userinterfaces;

import net.serenitybdd.screenplay.targets.Target;

public class CalculadoraPage {


	public static Target NUMERO = Target.the("digito")
			.locatedBy("//*[@resource-id='com.google.android.calculator:id/digit_{0}']");
	public static Target PUNTO = Target.the("Punto")
			.locatedBy("//*[@resource-id='com.google.android.calculator:id/dec_point']");
	public static Target OPERADOR = Target.the("Suma")
			.locatedBy("//*[@resource-id='com.google.android.calculator:id/op_{0}']");
	public static Target IGUAL = Target.the("resultado")
			.locatedBy("//*[@resource-id='com.google.android.calculator:id/eq']");


}
