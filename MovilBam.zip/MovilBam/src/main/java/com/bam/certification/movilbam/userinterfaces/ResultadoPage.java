package com.bam.certification.movilbam.userinterfaces;

import net.serenitybdd.screenplay.targets.Target;

public class ResultadoPage {

    public static Target VALOR_ESPERADO =Target.the("Campo_Resultado")
            .locatedBy("//*[@resource-id='com.google.android.calculator:id/result_final']");
}
