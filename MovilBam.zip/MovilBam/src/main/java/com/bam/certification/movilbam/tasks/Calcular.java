package com.bam.certification.movilbam.tasks;
import com.bam.certification.movilbam.interactions.OperacionInteraction;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import static com.bam.certification.movilbam.userinterfaces.CalculadoraPage.*;

public class Calcular implements Task{
	private String num1, num2, operador;
	
	public Calcular(String num1) {
		this.num1 = num1;
	}
	@Override
	public <T extends Actor> void performAs(T actor) {
		actor.attemptsTo(
				OperacionInteraction.clicEn(num1)
				,Click.on(OPERADOR.of(operador))
			   ,OperacionInteraction.clicEn(num2)
			   , Click.on(IGUAL));
		}

	public static Calcular laOperacion(String num1) {
		return Tasks.instrumented(Calcular.class, num1);
	}

	public Calcular operandoElNumeroUno(String operador) {
		this.operador=operador;
		return this;
	}

	public Calcular conElSegundoNumero(String num2) {
		this.num2=num2;

		return this;
	}
}
