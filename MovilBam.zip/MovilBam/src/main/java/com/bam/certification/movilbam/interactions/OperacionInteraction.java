package com.bam.certification.movilbam.interactions;
import com.bam.certification.movilbam.userinterfaces.CalculadoraPage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Interaction;
import net.serenitybdd.screenplay.Tasks;

public class OperacionInteraction implements Interaction{
	private String num;
		public OperacionInteraction(String num) {
			this.num = num;
	}
	@Override
	public <T extends Actor> void performAs(T actor) {
				for (int i = 0; i < num.length(); i++) {
			if (Character.toString(num.charAt(i)).equals(".")) {
				CalculadoraPage.PUNTO.resolveFor(actor).click();
			}
			else {
				CalculadoraPage.NUMERO.of(Character.toString(num.charAt(i))).resolveFor(actor).click();
			}
		}
	}
	public static OperacionInteraction clicEn(String num) {
		return Tasks.instrumented(OperacionInteraction.class, num);
	}
}
