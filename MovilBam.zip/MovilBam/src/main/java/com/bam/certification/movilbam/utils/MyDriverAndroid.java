package com.bam.certification.movilbam.utils;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.remote.MobileCapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import java.net.MalformedURLException;
import java.net.URL;

public class MyDriverAndroid {

    private static AppiumDriver<MobileElement> drivercalc;

    public AppiumDriver<MobileElement> abrirApp() {
        return drivercalc;
    }
    public  static MyDriverAndroid dirver() throws MalformedURLException {
        DesiredCapabilities appCapabilities = new DesiredCapabilities();
        appCapabilities.setCapability("device","Android");
        appCapabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "ZY32BHB2P5");
        appCapabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
        appCapabilities.setCapability("platformVersion", "10");
        appCapabilities.setCapability("appPackage", "com.google.android.calculator");
        appCapabilities.setCapability("appActivity", "com.android.calculator2.Calculator");
        appCapabilities.setCapability("automationName", "UiAutomator2");
        appCapabilities.setCapability("noReset", true);
        appCapabilities.setCapability("takesScreenshot",true);

        drivercalc =  new AppiumDriver<MobileElement>(
                new URL("http://127.0.0.1:4723/wd/hub"), appCapabilities);

        System.out.println("app is launched on the device");
        return new MyDriverAndroid();
    }

}
